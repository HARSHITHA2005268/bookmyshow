import React from "react";

const SearchBar = () => {
  return (
    <div>
      <input type="text" placeholder="Search for movies..." />
    </div>
  );
};

export default SearchBar;
